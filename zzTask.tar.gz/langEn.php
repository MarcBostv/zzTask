<?php
/* 
------------------
Language: English
------------------
*/
 
$lang = array();
 
$lang['PAGE_TITLE'] = 'Tasks Manager';
$lang['HEADER_TITLE'] = 'PoZZ it';
$lang['CREATE_TASK'] = 'Create a task';
$lang['CREATING_TASK'] = 'Creating a task';
$lang['ID'] = 'Please, Log in';
$lang['ID_FIELD'] = 'Your id';
$lang['PASSWORD_FIELD'] = 'Password';
$lang['LOGIN'] = 'Log in';
$lang['LOGOUT'] = 'Log out';
$lang['TEXT_INPUT'] = 'Task name';
$lang['DATE_START'] = 'Start (jj/mm/aaaa)';
$lang['DATE_STOP'] = 'End (jj/mm/aaaa)';
$lang['DESCRIPTION'] = 'Description';
$lang['CREATE'] = 'Create';
?>
